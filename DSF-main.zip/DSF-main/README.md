# Data science fundamentals course FS-2024

[Overview of the Course](https://docs.google.com/document/d/1vHfwF-Ihm3sPvYmK_yKFziafx4mITzyQAGAUyDzX6a8/edit)

[Repository of the DSF course](https://github.com/sigvehaug/DSF-DCBP)


## List of packages used / learned in the course:
- Pandas
- Numpy
- Matplotlib
- opencv
- scikit image
- Pillow
- OS


